import React from "react";

const Avator = () => {
  return <div>Avator</div>;
};

export default Avator;
