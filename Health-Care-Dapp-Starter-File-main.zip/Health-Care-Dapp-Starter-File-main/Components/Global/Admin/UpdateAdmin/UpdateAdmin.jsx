import React from "react";

const UpdateAdmin = () => {
  return <div>UpdateAdmin</div>;
};

export default UpdateAdmin;
