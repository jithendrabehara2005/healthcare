import React from "react";

const Prescription = () => {
  return <div>Prescription</div>;
};

export default Prescription;
