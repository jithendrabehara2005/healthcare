import React from "react";

const Doctors = () => {
  return <div>Doctors</div>;
};

export default Doctors;
