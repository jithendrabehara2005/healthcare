import React from "react";

function Auth() {
  return <div>Auth</div>;
}

export default Auth;
