import React from "react";

const MedicDetails = () => {
  return <div>MedicDetails</div>;
};

export default MedicDetails;
