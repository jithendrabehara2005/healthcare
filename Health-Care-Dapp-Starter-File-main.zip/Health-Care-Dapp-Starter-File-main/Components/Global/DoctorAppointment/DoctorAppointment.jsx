import React from "react";

const DoctorAppointment = () => {
  return <div>DoctorAppointment</div>;
};

export default DoctorAppointment;
