import React from "react";

const Appointment = () => {
  return <div>Appointment</div>;
};

export default Appointment;
