import React from "react";

const Medicine = () => {
  return <div>Medicine</div>;
};

export default Medicine;
