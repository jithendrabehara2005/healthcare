import React from "react";

const Message = () => {
  return <div>Message</div>;
};

export default Message;
