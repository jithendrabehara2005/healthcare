import React from "react";

const AppoinmentList = () => {
  return <div>AppoinmentList</div>;
};

export default AppoinmentList;
