import React from "react";

const MedicialHistory = () => {
  return <div>MedicialHistory</div>;
};

export default MedicialHistory;
