import React from "react";

const ChatBox = () => {
  return <div>ChatBox</div>;
};

export default ChatBox;
