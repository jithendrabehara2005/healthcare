import React from "react";

const AddDoctor = () => {
  return <div>AddDoctor</div>;
};

export default AddDoctor;
