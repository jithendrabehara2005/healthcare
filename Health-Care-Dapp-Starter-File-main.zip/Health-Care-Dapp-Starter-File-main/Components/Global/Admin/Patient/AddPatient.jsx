import React from "react";

const AddPatient = () => {
  return <div>AddPatient</div>;
};

export default AddPatient;
