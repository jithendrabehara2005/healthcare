import React from "react";

const Preloader = () => {
  return <div>Preloader</div>;
};

export default Preloader;
