import React from "react";

const StaffProfile = () => {
  return <div>StaffProfile</div>;
};

export default StaffProfile;
