import React from "react";

const Statistic = () => {
  return <div>Statistic</div>;
};

export default Statistic;
