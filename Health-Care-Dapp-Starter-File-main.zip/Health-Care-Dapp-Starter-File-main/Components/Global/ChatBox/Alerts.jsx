import React from "react";

const Alerts = () => {
  return <div>Alerts</div>;
};

export default Alerts;
