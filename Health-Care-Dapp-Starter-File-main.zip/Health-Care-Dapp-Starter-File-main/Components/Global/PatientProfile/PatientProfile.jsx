import React from "react";

const PatientProfile = () => {
  return <div>PatientProfile</div>;
};

export default PatientProfile;
