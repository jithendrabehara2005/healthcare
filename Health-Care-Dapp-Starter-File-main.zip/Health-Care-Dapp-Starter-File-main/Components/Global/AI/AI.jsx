import React from "react";

const AI = () => {
  return <div>AI</div>;
};

export default AI;
