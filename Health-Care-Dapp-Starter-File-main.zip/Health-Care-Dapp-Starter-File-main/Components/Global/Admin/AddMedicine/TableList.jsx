import React from "react";

const TableList = () => {
  return <div>TableList</div>;
};

export default TableList;
