import React from "react";

const AllAppoinments = () => {
  return <div>AllAppoinments</div>;
};

export default AllAppoinments;
