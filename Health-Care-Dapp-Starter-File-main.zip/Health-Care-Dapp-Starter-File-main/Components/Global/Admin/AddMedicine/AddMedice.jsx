import React from "react";

const AddMedice = () => {
  return <div>AddMedice</div>;
};

export default AddMedice;
