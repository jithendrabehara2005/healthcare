import React from "react";

const TableHead = () => {
  return <div>TableHead</div>;
};

export default TableHead;
