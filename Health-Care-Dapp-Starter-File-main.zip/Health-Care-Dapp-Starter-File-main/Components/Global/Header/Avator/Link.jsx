import React from "react";

const Link = () => {
  return <div>Link</div>;
};

export default Link;
