import React from "react";

const Gift = () => {
  return <div>Gift</div>;
};

export default Gift;
