import React from "react";

const ListCard = () => {
  return <div>ListCard</div>;
};

export default ListCard;
