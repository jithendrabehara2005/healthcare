import React from "react";

const UpdateStatus = () => {
  return <div>UpdateStatus</div>;
};

export default UpdateStatus;
