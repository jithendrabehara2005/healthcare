import React from "react";

const NavHeader = () => {
  return <div>NavHeader</div>;
};

export default NavHeader;
